import xbmcaddon

MainBase = 'http://billybobtv.net/movies/Home.txt'
addon = xbmcaddon.Addon('plugin.video.BillyBobTv')